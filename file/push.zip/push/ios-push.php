<?php

// your deviceToken is Here.
$deviceToken =    'c79a64c85697e7f797353359fffcb2eec1615233fcb02a97e5d73cc62e1ace47';


// Put your private key's passphrase here:
$passphrase = '123456';//证书的密码

// Put your alert message here:
$message = 'My first push notification!';

////////////////////////////////////////////////////////////////////////////////

$ctx = stream_context_create();
stream_context_set_option($ctx, 'ssl', 'local_cert', 'dev_ck.pem');
stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

// Open a connection to the APNS server
$fp = stream_socket_client(
	'ssl://gateway.sandbox.push.apple.com:2195', $err,
	$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

if (!$fp)
	exit("Failed to connect: $err $errstr" . PHP_EOL);

echo 'Connected to APNS' . PHP_EOL;

$alert = array(
				'body'=>’push测试2’,
				'action-loc-key'=>'ok');
// Create the payload body
$pushInfo['aps'] = array(
	'alert' => $alert,
	'sound' => '1',
	// 'content-available' => 1//,//for 静默下载。
	'badge' => 1
	);
$pushInfo['usrdefined'] = array('ptype'=>'5',
								'pushid'=>'4865',
								'appleid'=>'414430589',//458587755
								'cid'=>'91',//9001
								'aid'=>'',//1000000148351
								'vid'=>'9023216',//73337420  786622
								'site'=>'2',//2
								'ex1'=>'74',//7
								'lt'=>'1',
								'channeled'=>'81811225',
								'msgkind'=>'0',
								'enterId'=>'1_10000001',
								'callbackUrl'=>'http://api.tv.sohu.com/static/1.json');

// Encode the payload as JSON
$payload = json_encode($pushInfo);

// Build the binary notification
$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

// Send it to the server
$result = fwrite($fp, $msg, strlen($msg));

if (!$result)
	echo 'Message not delivered' . PHP_EOL;
else
	echo 'Message successfully delivered' . PHP_EOL;

// Close the connection to the server
fclose($fp);
