#!/bin/sh
xattr -r -d com.apple.quarantine ./VIPVideo.app

cp -rf ./VIPVideo.app /Applications

open ./VIPVideo.app
